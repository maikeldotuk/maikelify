# Zuckerbox
A Facebook cleaner with simplicity at its core
